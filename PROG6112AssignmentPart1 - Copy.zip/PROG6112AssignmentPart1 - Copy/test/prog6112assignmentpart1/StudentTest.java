/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog6112assignmentpart1;

import static java.lang.System.exit;
import java.util.Arrays;
import org.junit.Test;
//import java.lang.System.exit;
import static org.junit.Assert.*;

/**
 *
 * @author Dell 5420
 */
public class StudentTest {
    
    public StudentTest() {
    }

    @Test
    public void testSaveStudent() {
       // test to save student details
        Student.ID.clear();
        Student.name.clear();
        Student.course.clear();
        Student.email.clear();
        Student.age.clear();
        
    
        
        assertEquals(1,Student.age.size());
        assertEquals(1,Student.course.size());
        assertEquals(1,Student.email.size());
        assertEquals(1,Student.name.size());
        assertEquals(1,Student.ID.size());
        
        
        
    }

    @Test
    public void testSearchStudentList() {
        
    }

    @Test
    public void testDeleteStudent() {
        // test to see if using asList array cantest and remove the second item in the list
       Student.ID = Arrays.asList(1221,1211);
        Student.age = Arrays.asList(44,19);
         Student.course = Arrays.asList("bcom","bcad");
          Student.email = Arrays.asList("ab@bc.com","st@vc.com");
           Student.name = Arrays.asList("tom","jerry");
           
           assertEquals(2,Student.ID.size());
           assertEquals(2,Student.age.size());
           assertEquals(2,Student.course.size());
           assertEquals(2,Student.email.size());
           assertEquals(2,Student.name.size());
           
        
    }

    @Test
    public void testStudentReport() {
    }

    @Test
    
    public void testExitStudentApplication() {
     //  exit.expectSystemExitWithStatus(0);
    }
    
}
