/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112assignmentpart1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Dell 5420
 */ 
public class Student {
  static  Scanner kb = new Scanner(System.in);
  
 
  
  
  // array lists to collect and save the information that the user will input
  static List<Integer> ID = new ArrayList<>();
  static List<String> name = new ArrayList<>();
  static List<String> email = new ArrayList<>();
  static List<Integer> age = new ArrayList<>();
  static List<String> course = new ArrayList<>();

   

   
  
  // this method is used to display what information is needed to be input by the user
  // as well as provide a line for the user to input their answer
    public static void saveStudent()
    {
       
        
        Scanner kb = new Scanner(System.in);
        int input;
        
         
         System.out.println("enter student course:");
          String Course = kb.nextLine();
        
         System.out.println("enter student email:");
          String Email = kb.nextLine();
        
         System.out.println("enter name of student:");
          String Name = kb.nextLine();
        
         System.out.println("enter student ID:");
          int id = kb.nextInt();
       
         
          System.out.println("enter student age:");
          int Age = kb.nextInt();
          
         
           
         while(Age<13)
         {
             System.out.println("invalid age, please re-enter age");
              kb.nextInt();
              break;
         }  
              
        System.out.println();
        
          
         
            
              System.out.println("press (1) to return to menu or a different key to exit");
              input = kb.nextInt();
               if (input== 1) {
              
                   
    
        } else if (input != 1) {
                   System.exit(0);
        }
           
               System.out.println("student details have been saved \n");
    
       // the .add is used to save the input information to memory so that it can be recall at a later stage  
       ID.add(id);
       name.add(Name);
       email.add(Email);
       course.add(Course);
       age.add(Age);
    }
    
    // this method is used for the user to call up a specific student report that has been saved in the program
    public static  void searchStudentList(List<Integer> ID, List<String> name, List<String> email, List<Integer> age, List<String> course )
    {
        System.out.println("enter the student number that you want to find");
        int search = kb.nextInt();
        boolean found = false;   
                
            
        for (int i = 0; i < ID.size(); i++) {
            if (search == ID.get(i)) {
                
            
        
              System.out.println("student "+(i+1)+"\n"
                + "----------------------------------- \n"
                + "student ID:"+ ID.get(i)+"\n"
                + "student name:"+name.get(i)+"\n"
                + "student age:"+ age.get(i)+"\n"
                + "student email:"+email.get(i)+"\n"
                + "student course:"+course.get(i)+"\n"
                + "------------------------------------");
              found = true;
            }
        }
         if(!found) {
                System.out.println(" ivalid search try again");
                }
           
          System.out.println("press (1) to return to menu or a different key to exit");
           int   input = kb.nextInt();
               if (input== 1) {
              
                   
    
        } else if (input != 1) {
                   System.exit(0);
        }
        
      
        
    }
    
     // this method is used for the user to call up a specific student report
    // the selected student will then be removed from the program
    public static void deleteStudent(List<Integer> ID, List<String> name, List<String> email, List<Integer> age, List<String> course)
    {
        
        System.out.println("choose which student you want to remove by entering their student ID");
        int remove = kb.nextInt();
        boolean found = false;
        
        
            
        
        for (int i = 0; i < ID.size(); i++) {
            if (remove == ID.get(i)) {
                
            
            ID.remove(i);
            name.remove(i);
            email.remove(i);
            age.remove(i);
            course.remove(i);
            
            found = true;
            }  
        }
        
        
        if(!found) {
                System.out.println(" ivalid search try again");
                }
        
        
          System.out.println("press (1) to return to menu or a different key to exit");
            int  input = kb.nextInt();
               if (input== 1) {
              
                   
    
        } else if (input != 1) {
                   System.exit(0);
        }
        
           //get the element from array list
           //String str = animals.remove(2);
          // System.out.println("updated ArrayList:");
          // System.out.println("removed element :"+ str);
    }
    
    // this method is used to display all the student reports that have been saved
    public static void studentReport()
    { Scanner kb = new Scanner(System.in);
        for (int i = 0; i < ID.size(); i++) {
            
        
        System.out.println("student "+(i+1)+"\n"
                + "----------------------------------- \n"
                + "student ID:"+ ID.get(i)+"\n"
                + "student name:"+name.get(i)+"\n"
                + "student age:"+ age.get(i)+"\n"
                + "student email:"+email.get(i)+"\n"
                + "student course:"+course.get(i)+"\n"
                + "------------------------------------");
    }
          System.out.println("press (1) to return to menu or a different key to exit");
             int input = kb.nextInt();
               if (input== 1) {
              
                   
    
        } else if (input != 1) {
                   System.exit(0);
        }
    }
    
    // an exit option to end the program
    public static void exitStudentApplication()
    {
        
     System.exit(0);
    }

    }
