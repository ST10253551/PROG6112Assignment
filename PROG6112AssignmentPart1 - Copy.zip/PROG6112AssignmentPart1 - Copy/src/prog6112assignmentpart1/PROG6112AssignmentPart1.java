/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog6112assignmentpart1;

import java.util.Scanner;
import static prog6112assignmentpart1.Student.ID;
import static prog6112assignmentpart1.Student.age;
import static prog6112assignmentpart1.Student.course;
import static prog6112assignmentpart1.Student.email;
import static prog6112assignmentpart1.Student.name;

/**
 *
 * @author Dell 5420
 * Farrell, J. (2019). Java programming. Australia: Cengage Learning.
 * Stack Overflow. (n.d.). java - How to write a Unit Test? [online] Available at: https://stackoverflow.com/questions/8751553/how-to-write-a-unit-test.
 */
public class PROG6112AssignmentPart1 {

    /**
     * @param args the command line arguments
     */     
    
    //the main is used to display the primary menu for the program and give options to which action the user wants the program to initiate
    public static void main(String[] args) {
     int start; 
     int menuchoice = 0;
     
     Student student = new Student();
     
         Scanner kb = new Scanner(System.in);
         
        System.out.println(" STUDENT MANAGEMENT APPLICATION \n"
                + " ***************************** \n"
                + "Enter (1) to launch menu or any other key to exit");
        
                 start =kb.nextInt(); 
                 
               while(start==1){ 
                    if (start == 1) {
                    
            
                
                   
                        System.out.println("please select one of the following menu items:\n"
                                + "(1) Capture a new student \n"
                                + "(2) Serch for a student \n"
                                + "(3) Delete a student \n"
                                + "(4) Print student report \n"
                                + "(5) exit application");
                        
                        int menuChoice = kb.nextInt();
                       //switch used to call the methods from the student class into the main
                        switch(menuChoice){
                            case 1:Student.saveStudent(); break;
                            case 2:Student.searchStudentList(ID, name, email, age, course); break;
                            case 3:Student.deleteStudent(ID, name, email, age, course); break;
                            case 4:Student.studentReport(); break;
                            case 5:Student.exitStudentApplication(); break;
                                default: System.out.println("invalid ");
                             return;   
                        }
                        
                    } else {
                     System.out.println("end of program");
                     System.exit(0);
                     }
                }
      
 
}
}



