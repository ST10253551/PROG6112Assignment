/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inheritancequestioncustomer;

/**
 *
 * @author Dell 5420
 */
public class bankAccount  {
    private String bankNumber;
    private String userDetails;
    double bankBalance;

    public bankAccount(String bankNumber, String userDetails, double bankBalance) {
        this.bankNumber = bankNumber;
        this.userDetails = userDetails;
        this.bankBalance = bankBalance;
    }

   
// bankBalance += amount is used to add the input amount to the balance
    public void deposit(double amount)
    {
        bankBalance += amount;
    }
    //bankBalance -= amount is used to subtract the input amount to the balance
    public void withdraw(double amount)
    {
        if (bankBalance >= amount) {
            bankBalance -= amount;
            
        } else {
            System.out.println("insufficient funds in account ");
        }
    }
    
     public String getBankNumber() {
        return bankNumber;
    }

    public String getUserDetails() {
        return userDetails;
    }

    public double getBankBalance() {
        return bankBalance;
    }
     
}
