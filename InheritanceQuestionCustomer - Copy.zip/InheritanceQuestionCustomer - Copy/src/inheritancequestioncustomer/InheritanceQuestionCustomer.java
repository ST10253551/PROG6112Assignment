/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inheritancequestioncustomer;

import java.util.Scanner;
import javax.swing.JOptionPane;



 
public class InheritanceQuestionCustomer {
   


    /**
     * 
     * www.youtube.com. (n.b.) The Assignment Operator in java.[online]
     */
    public static void main(String[] args) {
       
       Scanner kb = new Scanner(System.in);
       bankAccount[] ba = new bankAccount[2];
       
       // array to save the information of the bank account and saving account
      ba[0]= new bankAccount("ZA 94 ROBN 194594 20102023","Nelson Mandela", 10000);
      ba[1]= new savingAccount("SS 15 BLCH 694320 19952019 ", "ichigo kurosaki", 0.15 , 3232);
      
      int start; 
     int menuchoice = 0;
         
        System.out.println("Enter (1) to launch bank menu or any other key to exit");
        
                 start =kb.nextInt(); 
                 
           
                    if (start == 1) {
                    
                        System.out.println("please select one of the following menu items:\n"
                                + "(1) bank account deposit\n"
                                + "(2) banking account withdraw\n"
                                + "(3) saving account interest\n"
                                + "(4) exit application\n");
                        
                        int menuChoice = kb.nextInt();
                       //switch used to select if money is being withdrawn or deposited
                        switch(menuChoice){
                            case 1:System.out.println("enter bank number ");
                                   String bankAccount = kb.nextLine();
                                   System.out.println("enter amount to deposit into bank account");
                                   double depositAmountB = kb.nextDouble();
                                   for (bankAccount account : ba)
                                   {
                                       if (account != null && account.getBankNumber().equals(bankAccount))
                                       {
                                        account.deposit(depositAmountB);
                                           System.out.println("transfer successful");
                                       }
                                   }
                                   break;
                                   
                            case 2:System.out.println("enter bank number ");
                                   String bankAccount2 = kb.nextLine();
                                   System.out.println("enter amount to withdraw from bank account");
                                   double withdrawAmountS = kb.nextDouble();
                                   for (bankAccount account : ba)
                                   {
                                       if (account != null && account.getBankNumber().equals(bankAccount2))
                                       {
                                        account.withdraw(withdrawAmountS);
                                           System.out.println("transfer successful");
                                       }
                                   }
                                   
                                    break;
                            
                            case 3:System.out.println("enter bank number for savings account ");
                                   String savingAccount = kb.nextLine();
                                   for (bankAccount account : ba) {
                                       if (account instanceof savingAccount && account.getBankNumber().equals(savingAccount)) {
                                           System.out.println("enter number of years");
                                           int years = kb.nextInt();
                                           ((savingAccount) account).calc(years);
                                           System.out.println("interest calculated");
                                       }
                                }
                                   break;
                            
                            case 4:System.exit(0); break;
                          
                                default: System.out.println("invalid ");
                             return;   
                        }
                        
                    } else {
                     System.out.println("end of program");
                     System.exit(0);
                     }
             
      
      
        
        
    }
    }
    

  
       
    