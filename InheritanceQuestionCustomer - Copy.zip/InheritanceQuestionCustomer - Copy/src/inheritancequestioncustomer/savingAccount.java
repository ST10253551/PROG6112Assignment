/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inheritancequestioncustomer;

/**
 *
 * @author Dell 5420
 */
public class savingAccount extends bankAccount{
    
    private double INTEREST_RATE = 0.15;
    
    public savingAccount(String bankNumber, String userDetails, double INTEREST_RATE, double bankBalance)        
    {
        super(bankNumber, userDetails, bankBalance);
        this.INTEREST_RATE = INTEREST_RATE;
    }
            
    public void calc(int year)
            //simple interest calculation for the saving account
    {
        double interest = bankBalance*INTEREST_RATE*year;
        bankBalance  += interest;
    }
}
