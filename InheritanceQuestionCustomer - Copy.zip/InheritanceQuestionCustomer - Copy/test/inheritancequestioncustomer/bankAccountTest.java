/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package inheritancequestioncustomer;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Dell 5420
 */
public class bankAccountTest {
    
    public bankAccountTest() {
    }

    @Test
    public void testDeposit() {
        //unit test to test if addition works
        bankAccount ba = new bankAccount("cidn 11221", "john cena", 999);
        ba.deposit(1);
        assertEquals(1000,ba.getBankBalance(),0.001);
        
    }

    @Test
    public void testWithdraw() {
        // unit test to test if subtraction works
        bankAccount ba = new bankAccount("cidn 11221", "john cena", 1000);
         ba.withdraw(1);
          assertEquals(999,ba.getBankBalance(),0.001);
     
    }

    
    
}
